<?php

/**
 * Blog
 *
 * @package smartproperties
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
?>

 <?php  
   get_template_part( 'template-parts/content', 'blog' );
    ?>

<?php get_footer(); ?>





