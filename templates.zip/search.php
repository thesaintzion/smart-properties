<?php

/**
 * Archive
 *
 * @package smartproperties
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
?>
<h1>SEARCH</h1>
 <?php    get_template_part( 'template-parts/content', 'blog' ); ?>

<?php get_footer(); ?>
