<?php
/**
 * About Us custom template
 *
 * @package smartproperties
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php    get_template_part( 'template-parts/content', 'properties' ); ?>

<?php get_footer(); ?>






